Multiple parsimony alignment with "affalign"
--------------------------------------------

In this directory, there is a linux binary called "affalign". The
program performs multiple optimal parsimony alignment over a
tree. Here is how to use it:

  affalign <costfile> <tree> <seq1> <seq2> <seq3> ....  [<g_I> <g_e>]

The first argument is a cost file. There is one included here:
"codon_dist.cost".

The second argument is the tree, where seqeunces are reference by a
number: 1, 2, 3, ...

The folowing arguments are the sequences 1, 2, 3, ...

A gap introduction and extension score may be gives as optional
arguments in the end, which overrules the gap parameters in the cost
file.


The cost file
-------------

Notice that the prgram is ditance based, so it uses positive costs for
all replacements and zero for identical residues. Similarity based
scores are difficult to deal with on a tree.

The file "codon_dist.cost" uses codon mutation distances as costs. The
cost is 10 for each mutation on the shortest path from a codon for
amino acid one to a codon for amino acid two.

The gap introduction cost is 50 and the gap extension cost is 20. All
costs are integers.

It should be easy to see how the file is set up to create your own.


Examples
--------

To align the two sequences "AGRE" and "ATSRR", use:

  affalign codon_dist.cost "(1,2);" "AGRE" "ATSRR"

And obtain the output:

  Number of sequences: 2
  Score: 80
  Alignment:
  A-GRE
  ATSRR


To use a gap introduction cost of 10 and an extension cost of 5, use:

  affalign codon_dist.cost "(1,2);" "AGRE" "ATSRR" 10 5

And obtain the output:

  Number of sequences: 2
  Score: 35
  Alignment:
  A--GRE
  ATSRR-


To align three sequences with a gap introduction cost of 4 and
an extension cost of 1, use:

  affalign codon_dist.cost "(1,2,3);" "ATHSGR" "ATGR" "ASGR" 4 1

And obtain the output:

  Number of sequences: 3
  Score: 10
  Alignment:
  ATHSGR
  AT--GR
  A--SGR


To align four sequences, use:

  affalign codon_dist.cost "((1,2),(3,4));"  "ATHSGR" "ATGR" "GTHGR" "GTHGK"

And so on.


Time and memory usage
---------------------

On my pentium 700 MHz machine, the time and memory usages for a
triple alignment are:

Length    Time      Memory

  40     3.8 sec    3.7 Mb
  80    24.3 sec     24 Mb
 160     188 sec    183 Mb

The Hirschberg trick has not been implemented yet. It would lower the
memory usage by the order of the sequence lengths and increase the
time usage by a factor of at most two.
