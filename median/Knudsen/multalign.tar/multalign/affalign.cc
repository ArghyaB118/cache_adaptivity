#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <math.h>
#define INF 30000

using namespace std;

// ------------------------------------------------------------

// The type used for scores
typedef short int cost_int;

// The scoring scheme
class Cost
{
public:
  Cost(istream &str);

  cost_int get_g_i() const;
  cost_int get_g_e() const;
  cost_int get_match(int i, int j) const;
  string const &get_alphabet() const;
  int get_numres() const;

  void set_g_i(cost_int c);
  void set_g_e(cost_int c);

private:
  string alphabet;     // The residue alphabet
  int numres;         // Number of different residues
  cost_int g_i;        // Gap introduction cost;
  cost_int g_e;        // Gap extension cost;
  cost_int **match;    // Match cost matrix
};

class Seq
{
public:
  Seq(string const &s, Cost *cost);
  int getlength() const;
  int getres(int pos) const;
  char getsym(int pos) const;

private:
  vector< int > res;
  string str;
};

// Nodes in the tree
class Node
{
public:
  Node();

  void addchild(Node *n);
  Node *getchild() const;
  Node *getbrother() const;
  Node *getparent() const;
  void setnumber(int n);
  int getnumber() const;
  bool hasseq;
  vector< cost_int > down_cost;

private:
  Node *child;
  Node *brother;
  Node *parent;
  int number;
};

// The tree
class Tree
{
public:
  Tree(string const &s);

  Node *getroot() const;
  int getnumseq() const;
  int getnumnode() const;
  void init(Cost *cost);
  cost_int sub_cost(vector< int > const &res, Cost *cost) const;

private:
  Node *root;
  int numseq;
  int numnode;
};

// Jumping from one point in the prefix alignment matrix to another.
// From one indel configuration to another via a residue
// configuration.
class Jump
{
public:
  Jump(int ic1, int rc, int ic2, int g_cost);
  int get_start_indel_conf() const;
  int get_end_indel_conf() const;
  int get_length() const;
  void set_length(int n);
  int get_res_conf() const;
  cost_int get_gap_cost() const;

private:
  int start_indel_conf;// The starting indel configuration
  int end_indel_conf;  // The resulting indel configuration
  int length;          // Length of jump in matrix, not including changes in
                       // indel configuration
  int res_conf;        // The residue configuration
  cost_int gap_cost;   // The gap cost associated with this jump
};

// List of jumps and such
class Jumplist
{
public:
  Jumplist(Tree const &tree, Cost *cost);
  void setlength(vector< Seq > const &seqs);
  int maxlength(vector< Seq > const &seqs) const;
  int totlength(vector< Seq > const &seqs) const;
  vector< Jump > const &getlist() const;
  cost_int get_match_cost(vector< int > const &res);
  int get_res_conf(int rcnum, int pos) const;
  int get_indel_conf(int icnum, int pos) const;
  int indelmap(int icnum) const;
  int get_num_indel_conf() const;

private:
  vector< Jump > jmp;        // Vector of jumps
  vector< bool > indel_acc;  // Which indel configuration numbers are
                             // acceptable
  vector< bool > res_acc;    // Which residue configuration numbers are
                             // acceptable
  vector< vector< int > > res_conf;
                             // Residue configuration by number
  vector< vector< int > > indel_conf;
                             // Indel configuration by number
  map< vector< int >, cost_int > match_cost;
  cost_int **match_cost_2;  // Hardcode two,
  cost_int ***match_cost_3;  // three, and four residues
  cost_int ****match_cost_4; // since map is slow
  vector< int > rmap;
  vector< int > imap;
  int num_seq;
};


// ------------------------------------------------------------

void usage();
bool res_conf_check(Tree const &tree, vector< int > const &res_conf);
bool indel_conf_check(Tree const &tree, vector< int > const &indel_conf);
cost_int apply_res_conf(Tree const &tree, Cost *cost,
			vector< int > const &indel_conf,
			vector< int > const &res_conf,
			vector< int > &indel_conf2);

int indelnum(vector< int > const &ic);
int resnum(vector< int > const &rc);

void align_mid(Tree const &tree, Jumplist &jumplist, vector< Seq > const &seqs);  

void align(Tree const &tree, Jumplist &jumplist, vector< Seq > const &seqs);  

// ------------------------------------------------------------

int main (int argc, char **argv)
{
  ifstream f;
  Cost *cost;

  if (argc < 5)
    usage();

  f.open(argv[1]);
  if (!f.good()) {
    cerr << "mult: error in opening alignment cost file: " << argv[1] << endl;
    exit(1);
  }

  cost = new Cost(f);

  f.close();

  Tree tree(argv[2]); // Argument one is the tree

  tree.init(cost);

  cout << "Number of sequences: " << tree.getnumseq() << endl;

  if (argc == 5+tree.getnumseq()) {  // user specified gap cost
    cost->set_g_i(atoi(argv[tree.getnumseq()+3]));
    cost->set_g_e(atoi(argv[tree.getnumseq()+4]));
  }
  else if (argc != 3+tree.getnumseq())
    usage();

  Jumplist jumplist(tree, cost);

  vector< Seq > seqs;

  for (int i = 0; i < tree.getnumseq(); i++)
    seqs.push_back(Seq(argv[3+i], cost));

  align(tree, jumplist, seqs);

  return 0;
}


// ------------------------------------------------------------

Seq::Seq(string const &s, Cost *cost)
{
  for (int i = 0; i < s.size(); i++) {
    res.push_back(cost->get_alphabet().find(s[i]));
  }
  str = s;
}

int Seq::getlength() const
{
  return res.size();
}

int Seq::getres(int pos) const
{
  return res[pos];
}

char Seq::getsym(int pos) const
{
  return str[pos];
}


// ------------------------------------------------------------

Cost::Cost(istream &str)
{
  string s;

  str >> alphabet;
  str >> g_i;
  str >> g_e;

  numres = alphabet.size();

  match = new cost_int *[numres];

  for (int i = 0; i < numres; i++) {
    match[i] = new cost_int[numres];
    getline(str, s);
    for (int j = 0; j < numres; j++)
      str >> match[i][j];
  }
}

cost_int Cost::get_g_i() const
{
  return g_i;
}

cost_int Cost::get_g_e() const
{
  return g_e;
}

cost_int Cost::get_match(int i, int j) const
{
  return match[i][j];
}

string const &Cost::get_alphabet() const
{
  return alphabet;
}

int Cost::get_numres() const
{
  return numres;
}

void Cost::set_g_i(cost_int c)
{
  g_i = c;
}

void Cost::set_g_e(cost_int c)
{
  g_e = c;
}


// ------------------------------------------------------------

// Make a tree from a string in Newick format.
Tree::Tree(string const &s)
{
  Node *tmp, *current;
  int c;

  root = new Node;

  current = root;

  int ptr = 0;  // Pointer in the tree string

  for (;;) {
    c = s[ptr];

    if (c == '(') {
      tmp = new Node;
      current->addchild(tmp);
      current = tmp;
      ptr++;
    }
    else if (c == ')') {
      if (current->getparent() == 0) {
	cerr << "Too many \')\'s" << endl;
	exit(1);
      }
      current = current->getparent();
      ptr++;
    }
    else if (c == ',') {
      tmp = new Node;
      if (current->getparent() == 0) {
	cerr << "Too many \')\'s" << endl;
	exit(1);
      }
      current->getparent()->addchild(tmp);
      current = tmp;
      ptr++;
    }
    else if (c == ';') {
      break;
    }
    else if (c == '\0') {
      cerr << "Expected tree to end on \';\'" << endl;
      exit(1);
    }
    else {
      int ptr2 = s.find_first_of("),;", ptr+1);
      int n = atoi(s.substr(ptr, ptr2-ptr).c_str());
      if (n <= 0) {
	cerr << "Sequence number must be positive" << endl;
	exit(1);
      }
      current->setnumber(n);
      current->hasseq = true;
      ptr = ptr2;
    }
  }

  if (current != root) {
    cerr << "Too many \'(\'s" << endl;
    exit(1);
  }
}

Node *Tree::getroot() const
{
  return root;
}

int Tree::getnumseq() const
{
  return numseq;
}

int Tree::getnumnode() const
{
  return numnode;
}

int rec_cs(Node *node);
int rec_sn(Node *node, int n);
void rec_init(Node *node, Cost *cost);

void Tree::init(Cost *cost)
{
  numseq = rec_cs(root);
  numnode = rec_sn(root, numseq);
  rec_init(root, cost);
}

// Recursion for finding number of sequences. Returns number of
// sequences in the subtree from the node down.
int rec_cs(Node *node)
{
  int i = 0;

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    i += rec_cs(np);
  }

  if (node->getnumber() != 0)
    i++;
    
  return i;
}

// Set the numbers of the nodes without sequences in post order,
// starting from n+1. Returns number of the node, argument one.
int rec_sn(Node *node, int n)
{
  for (Node *np = node->getchild(); np != 0; np = np->getbrother())
    n = rec_sn(np, n);

  if (node->getnumber() == 0)
    node->setnumber(++n);

  return n;
}

void rec_init(Node *node, Cost *cost)
{
  for (Node *np = node->getchild(); np != 0; np = np->getbrother())
    rec_init(np, cost);
  
  node->down_cost = vector< cost_int >(cost->get_numres());
}

int rec_rcc(Node *node, vector< int > const &res_conf);

bool res_conf_check(Tree const &tree, vector< int > const &res_conf)
{
  bool no_leaf = true;

  for (int i = 0; i < tree.getnumseq(); i++) // Check if all leaves
                                              // have a residue
    if (res_conf[i] == 1) {
      no_leaf = false;
      break;
    }

  if (no_leaf)
    return false;

  if (rec_rcc(tree.getroot(), res_conf) == 3)
    return false;
  else
    return true;
}

/*
In node i:

  res_conf[i] = 1 for residue
  res_conf[i] = 0 for gap


Return value    0        1        2        3

                #        -        -        -
Type           / \      / \      / \      / \
              #   -    #   -    -   -    #   #
*/
int rec_rcc(Node *node, vector< int > const &res_conf)
{
  bool res_below = false;

  int residue = res_conf[node->getnumber()-1];

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    int n = rec_rcc(np, res_conf);
    if (residue == 1) { // Residue at node
      if (n == 1 || n == 3) // Configuration unacceptable
	return 3;
    }
    else { // Gap at node
      if (n == 3) // Configuration unacceptable
	return 3;
      else if (n == 0 || n == 1) {
	if (res_below == true) // Configuration unacceptable
	  return 3;
	else
	  res_below = true;
      }
    }
  }

  if (residue == 0) {
    if (res_below == true)
      return 1;
    else
      return 2;
  }

  return 0;
}

int rec_icc(Node *node, vector< int > const &indel_conf);

bool indel_conf_check(Tree const &tree, vector< int > const &indel_conf)
{
  //  cout << rec_icc(tree.getroot(), indel_conf) << endl;

  if (rec_icc(tree.getroot(), indel_conf) == 2)
    return true;
  else
    return false;
}

/*
Arrow at edge over node i:

  indel_conf[i] = 2 down
  indel_conf[i] = 1 no direction
  indel_conf[i] = 0 up


Return value
0    root isolated from all leaves
1    one arrow reversal isolates root from all leaves
2    the rest of the acceptable configurations
3    unacceptable configuration
*/
int rec_icc(Node *node, vector< int > const &indel_conf)
{
  int rev_to_isolate = 0; // Number of arrow reversals to isolate root

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    int ic = indel_conf[np->getnumber()-1];
    int n = rec_icc(np, indel_conf);
    if (n == 3 ||
	(n == 0 && ic != 1) ||
	(n == 1 && ic == 2)) // Configuration unacceptable
      return 3;
    else if (n == 2 && ic == 1)
      rev_to_isolate += 2;
    else if ((n == 2 && ic == 2) ||
	     (n == 1 && ic == 1))
      rev_to_isolate += 1;
  }

  if (node->hasseq)
    return 2;
  
  if (rev_to_isolate == 0)
    return 0;
  else if (rev_to_isolate == 1)
    return 1;

  return 2;
}

cost_int rec_arc(Node *node, Cost *cost, vector< int > const &indel_conf,
		 vector< int > const &res_conf,
		 vector< int > &indel_conf2);

int rec_num_int(Node *node, vector< int > const &indel_conf,
		vector< int > const &res_conf,
		vector< int > &indel_conf2);

int rec_num_ext(Node *node, vector< int > const &indel_conf,
		vector< int > const &res_conf,
		vector< int > &indel_conf2);

// Apply res_conf to indel_conf and obtain indel_conf2. Returns gap
// cost.
cost_int apply_res_conf(Tree const &tree, Cost *cost,
			vector< int > const &indel_conf,
			vector< int > const &res_conf,
			vector< int > &indel_conf2)
{
  cost_int c = 0;

  c = rec_arc(tree.getroot(), cost,
	      indel_conf, res_conf, indel_conf2);
  /*
  bool gotindel = false;

  for (int i = 0; i < indel_conf.size(); i++)
    if (indel_conf[i] != 1 && (indel_conf[i] == indel_conf2[i])) {
      gotindel = true;
      break;
    }

  if (gotindel)
    c += rec_num_int(tree.getroot(), indel_conf, res_conf, indel_conf2)*(cost->get_g_i()-cost->get_g_e())/2;
  if (!gotindel && rec_num_int(tree.getroot(), indel_conf, res_conf, indel_conf2) > 0) // add introduction cost
    c += (cost->get_g_i()-cost->get_g_e()) +
      (cost->get_g_i()-cost->get_g_e())/2 * (rec_num_int(tree.getroot(), indel_conf, res_conf, indel_conf2)-1);

  //  if (!gotindel && rec_num_int(tree.getroot(), indel_conf, res_conf, indel_conf2) > 0) // add introduction cost
  //    c += cost->get_g_i()-cost->get_g_e();
  */
  return c;
}

cost_int rec_arc(Node *node, Cost *cost, vector< int > const &indel_conf,
		 vector< int > const &res_conf,
		 vector< int > &indel_conf2)
{
  cost_int c = 0;

  int parent_residue = res_conf[node->getnumber()-1];

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    c += rec_arc(np, cost, indel_conf, res_conf, indel_conf2);
    int child_residue = res_conf[np->getnumber()-1];
    if (parent_residue == 1 && child_residue == 0)
      indel_conf2[np->getnumber()-1] = 0;
    else if (parent_residue == 1 && child_residue == 1)
      indel_conf2[np->getnumber()-1] = 1;
    else if (parent_residue == 0 && child_residue == 1)
      indel_conf2[np->getnumber()-1] = 2;
    else
      indel_conf2[np->getnumber()-1] = indel_conf[np->getnumber()-1];
    if (child_residue != parent_residue) {
      if (indel_conf2[np->getnumber()-1] == indel_conf[np->getnumber()-1]) 
	c += cost->get_g_e();
      else
	//c += cost->get_g_e();
      	c += cost->get_g_i();
    }
  }

  return c;
}

int rec_num_int(Node *node, vector< int > const &indel_conf,
		     vector< int > const &res_conf,
		     vector< int > &indel_conf2)
{
  cost_int c = 0;

  int parent_residue = res_conf[node->getnumber()-1];

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    c += rec_num_int(np, indel_conf, res_conf, indel_conf2);
    int child_residue = res_conf[np->getnumber()-1];
    if (parent_residue == 1 && child_residue == 0)
      indel_conf2[np->getnumber()-1] = 0;
    else if (parent_residue == 1 && child_residue == 1)
      indel_conf2[np->getnumber()-1] = 1;
    else if (parent_residue == 0 && child_residue == 1)
      indel_conf2[np->getnumber()-1] = 2;
    else
      indel_conf2[np->getnumber()-1] = indel_conf[np->getnumber()-1];
    if (child_residue != parent_residue) {
      if (indel_conf2[np->getnumber()-1] != indel_conf[np->getnumber()-1]) 
	c++;
    }
  }

  return c;
}

int rec_num_ext(Node *node, vector< int > const &indel_conf,
		     vector< int > const &res_conf,
		     vector< int > &indel_conf2)
{
  cost_int c = 0;

  int parent_residue = res_conf[node->getnumber()-1];

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    c += rec_num_ext(np, indel_conf, res_conf, indel_conf2);
    int child_residue = res_conf[np->getnumber()-1];
    if (parent_residue == 1 && child_residue == 0)
      indel_conf2[np->getnumber()-1] = 0;
    else if (parent_residue == 1 && child_residue == 1)
      indel_conf2[np->getnumber()-1] = 1;
    else if (parent_residue == 0 && child_residue == 1)
      indel_conf2[np->getnumber()-1] = 2;
    else
      indel_conf2[np->getnumber()-1] = indel_conf[np->getnumber()-1];
    if (child_residue != parent_residue) {
      if (indel_conf2[np->getnumber()-1] == indel_conf[np->getnumber()-1]) 
	c++;
    }
  }

  return c;
}

cost_int rec_sc(Node *node, vector< int > const &res, Cost *cost);

cost_int Tree::sub_cost(vector< int > const &res, Cost *cost) const
{
  return rec_sc(root, res, cost);
}

cost_int rec_sc(Node *node, vector< int > const &res, Cost *cost)
{
  int numres = cost->get_numres();

  for (int i = 0; i < numres; i++)
    node->down_cost[i] = 0;

  for (Node *np = node->getchild(); np != 0; np = np->getbrother()) {
    rec_sc(np, res, cost);
    for (int i = 0; i < numres; i++) {
      cost_int s = INF;
      for (int j = 0; j < numres; j++)
	if (np->down_cost[j] != INF &&
	    (np->down_cost[j]+cost->get_match(i, j) < s) || s == INF)
	  s = np->down_cost[j]+cost->get_match(i, j);
      node->down_cost[i] += s;
    }
    //    cout << " [";
    //    for (int k = 0; k < numres; k++)
    //      cout << " " << node->down_cost[k];
    //    cout << " ]";
  }

  if (node->hasseq && res[node->getnumber()-1] != -1) {
                              // we have a sequence, not a gap
    for (int i = 0; i < numres; i++)
      if (i != res[node->getnumber()-1])
	node->down_cost[i] = INF;
  }
  
  //  cout << "<" << node->getnumber() << "  ";
  //  for (int k = 0; k < numres; k++)
  //    cout << " " << node->down_cost[k];

  cost_int s = INF;
  for (int j = 0; j < numres; j++)
    if (node->down_cost[j] != INF && ( node->down_cost[j] < s || s == INF))
      s = node->down_cost[j];

  //  cout << "  " << s << ">";

  return s;
}


// ------------------------------------------------------------

Node::Node()
{
  child = 0;
  brother = 0;
  parent = 0;
  number = 0;
  hasseq = false;
}

Node *Node::getchild() const
{
  return child;
}

Node *Node::getbrother() const
{
  return brother;
}

Node *Node::getparent() const
{
  return parent;
}

void Node::setnumber(int n)
{
  number = n;
}

int Node::getnumber() const
{
  return number;
}

void Node::addchild(Node *n)
{
  Node *tmp;

  n->brother = 0;
  n->parent = this;

  if (child == 0)
    child = n;
  else {
    for (tmp = child; tmp->brother != 0; tmp = tmp->brother)
      ;
    tmp->brother = n;
  }
}


// ------------------------------------------------------------

Jump::Jump(int ic1, int rc, int ic2, int g_cost)
{
  start_indel_conf = ic1;
  end_indel_conf = ic2;
  res_conf = rc;
  gap_cost = g_cost;
  length = 0;
}

int Jump::get_start_indel_conf() const
{
  return start_indel_conf;
}

int Jump::get_end_indel_conf() const
{
  return end_indel_conf;
}

int Jump::get_length() const
{
  return length;
}

void Jump::set_length(int n)
{
  length = n;
}

int Jump::get_res_conf() const
{
  return res_conf;
}

cost_int Jump::get_gap_cost() const
{
  return gap_cost;
}


// ------------------------------------------------------------


Jumplist::Jumplist(Tree const &tree, Cost *cost)
{
  int num_node = tree.getnumnode();
  num_seq = tree.getnumseq();
  int numres = cost->get_numres();

  vector< int > rc(num_node);

  for (int i = 0; i < num_node; i++)
    rc[i] = 0;

  for (;;) {  // Go through all residue configurations
    if (res_conf_check(tree, rc)) {
      res_acc.push_back(true);
      rmap.push_back(res_conf.size());
      res_conf.push_back(rc);
    }
    else {
      res_acc.push_back(false);
      rmap.push_back(-1);
    }

    int i;

    for (i = 0; i < num_node; i++) {
      rc[i]++;
      if (rc[i] == 2)
	rc[i] = 0;
      else
	break;
    }

    if (i == num_node)
      break;
  }


  vector< int > ic(num_node-1); // There is one less
                                // edge than the number of nodes

  for (int i = 0; i < num_node-1; i++)
    ic[i] = 0;

  for (;;) {
    if (indel_conf_check(tree, ic)) {
      indel_acc.push_back(true);
      imap.push_back(indel_conf.size());
      indel_conf.push_back(ic);
    }
    else {
      indel_acc.push_back(false);
      imap.push_back(-1);
    }

    int i;

    for (i = 0; i < num_node-1; i++) {
      ic[i]++;
      if (ic[i] == 3)
	ic[i] = 0;
      else
	break;
    }

    if (i == num_node-1)
      break;
  }

  for (int i = 0; i < indel_conf.size(); i++) {
    for (int j = 0; j < res_conf.size(); j++) {
      cost_int c = apply_res_conf(tree, cost, indel_conf[i], res_conf[j], ic);
      int n = indelnum(ic);
      if (indel_acc[n]) {
	jmp.push_back(Jump(i, j, imap[n], c));
      }
    }
  }

  vector< int > res(num_seq);

  for (int i = 0; i < num_seq; i++)
    res[i] = -1;

  if (num_seq == 2) {
    match_cost_2 = new cost_int *[numres+1];
    for (int i = 0; i < numres+1; i++)
      match_cost_2[i] = new cost_int [numres+1];
  }
  else if (num_seq == 3) {
    match_cost_3 = new cost_int **[numres+1];
    for (int i = 0; i < numres+1; i++) {
      match_cost_3[i] = new cost_int *[numres+1];
      for (int j = 0; j < numres+1; j++)
	match_cost_3[i][j] = new cost_int [numres+1];
    }
  }
  else if (num_seq == 4) {
    match_cost_4 = new cost_int ***[numres+1];
    for (int i = 0; i < numres+1; i++) {
      match_cost_4[i] = new cost_int **[numres+1];
      for (int j = 0; j < numres+1; j++) {
	match_cost_4[i][j] = new cost_int *[numres+1];
	for (int k = 0; k < numres+1; k++)
	  match_cost_4[i][j][k] = new cost_int [numres+1];
      }
    }
  }

  for (;;) {
    if (num_seq == 2) {
      match_cost_2[res[0]+1][res[1]+1] = tree.sub_cost(res, cost);
      //      if (match_cost_2[res[0]+1][res[1]+1] > 0)
      //      	match_cost_2[res[0]+1][res[1]+1]++;
    }
    else if (num_seq == 3) {
      match_cost_3[res[0]+1][res[1]+1][res[2]+1] = tree.sub_cost(res, cost);
      //      if (match_cost_3[res[0]+1][res[1]+1][res[2]+1] > 1)
      //      	match_cost_3[res[0]+1][res[1]+1][res[2]+1]++;
    }
    else if (num_seq == 4)
      match_cost_4[res[0]+1][res[1]+1][res[2]+1][res[3]+1] = tree.sub_cost(res, cost);
    else
      match_cost[res] = tree.sub_cost(res, cost);

    int i;

    for (i = 0; i < num_seq; i++) {
      res[i]++;
      if (res[i] == numres)
	res[i] = -1;
      else
	break;
    }

    if (i == num_seq)
      break;
  }
}

void Jumplist::setlength(vector< Seq > const &seqs)
{
  int num_seq = seqs.size();

  for (int k = 0; k < jmp.size(); k++) {
    int n = 0;
    int rc_num = jmp[k].get_res_conf();
    for (int i = num_seq-1; i >= 0; i--) {
      n *= (seqs[i].getlength()+1);
      n += res_conf[rc_num][i];
    }
    n *= indel_conf.size();
    jmp[k].set_length(n);
  }
}

// Maximum possible jump length
int Jumplist::maxlength(vector< Seq > const &seqs) const
{
  int num_seq = seqs.size();
  int n = 0;
  
  for (int i = num_seq-1; i >= 0; i--) {
    n *= (seqs[i].getlength()+1);
    n++;
  }
  n++; // to accomodate the worst indel conf change
  n *= indel_conf.size();

  return n;
}

// Total matrix size
int Jumplist::totlength(vector< Seq > const &seqs) const
{
  int num_seq = seqs.size();

  int n = 1;
  for (int i = 0; i < num_seq; i++) {
    n *= (seqs[i].getlength()+1);
  }
  n *= indel_conf.size();

  return n;
}

vector< Jump > const &Jumplist::getlist() const
{
  return jmp;
}

cost_int Jumplist::get_match_cost(vector< int > const &res)
{
  if (num_seq == 2)
    return match_cost_2[res[0]+1][res[1]+1];
  else if (num_seq == 3)
    return match_cost_3[res[0]+1][res[1]+1][res[2]+1];
  else if (num_seq == 4)
    return match_cost_4[res[0]+1][res[1]+1][res[2]+1][res[3]+1];

  return match_cost[res];
}

int Jumplist::get_res_conf(int rcnum, int pos) const
{
  return res_conf[rcnum][pos];
}

int Jumplist::get_indel_conf(int icnum, int pos) const
{
  return indel_conf[icnum][pos];
}

int Jumplist::indelmap(int icnum) const
{
  return imap[icnum];
}

int Jumplist::get_num_indel_conf() const
{
  return indel_conf.size();
}


// ------------------------------------------------------------

void usage()
{
  cerr << "usage: affalign <costfile> <tree> <seq1> <seq2> <seq3> ....  [<g_I> <g_e>]" << endl;
  exit(1);
}

int indelnum(vector< int > const &ic)
{
  int n = 0, p = 1;

  for (int i = 0; i < ic.size(); i++, p*= 3) {
    n += ic[i]*p;
  }

  return n;
}

int resnum(vector< int > const &rc)
{
  int n = 0, p = 1;

  for (int i = 0; i < rc.size(); i++, p*= 2) {
    n += rc[i]*p;
  }

  return n;
}

void align_mid(Tree const &tree, Jumplist &jumplist, vector< Seq > const &seqs)
{
  int ml = jumplist.maxlength(seqs);

  int num_seq = seqs.size();
  int num_node = tree.getnumnode();

  jumplist.setlength(seqs);

  vector< Jump > jlist = jumplist.getlist();
  int numjump = jlist.size();
  int num_iconf = jumplist.get_num_indel_conf();

  int row = seqs[num_seq-1].getlength()/2;

  int row_size = 1;
  //  for (int i = 0; i < num_seq-1; i++) {
  //    row_size *= (seqs[i].getlength()+1);
  //  }
  //  row_size *= num_iconf;

  vector<cost_int> score(ml);

  for (int i = 0; i < ml; i++)
    score[i] = INF;

  int n = 1;
  for (int i = 0; i < num_node-2; i++) {
    n *= 3;
    n++;
  }

  score[jumplist.indelmap(n)] = 0;

    cout << "Start conf: " << jumplist.indelmap(n) << endl;

  vector< int > pos(num_seq);
  vector< int > res_next(num_seq);
  vector< int > res(num_seq);

  for (int i = 0; i < num_seq; i++)
    pos[i] = 0;

  for (int i = 0; i < num_seq; i++)
    res_next[i] = seqs[i].getres(pos[0]);

  int ptr = 0;

  for (;;) {
    for (int k = 0; k < numjump; k++) {
      cost_int c = jlist[k].get_gap_cost();
      bool no_good = false;
      for (int j = 0; j < num_seq; j++) {
	int rc_j = jumplist.get_res_conf(jlist[k].get_res_conf(), j);
	if (rc_j == 0)
	  res[j] = -1;
	else {
	  if (pos[j] < seqs[j].getlength() &&
	      (j < num_seq-1 || pos[j] < row))
	    res[j] = res_next[j];
	  else
	    no_good = true;
	}
      }
      if (no_good)
	continue;
      c += jumplist.get_match_cost(res);
      cost_int sc_src = score[(ptr+jlist[k].get_start_indel_conf()) % ml];
      int dst_ptr = (ptr+jlist[k].get_end_indel_conf()
		     +jlist[k].get_length()) % ml;
      cost_int sc_dst = score[dst_ptr];
      if (sc_src != INF && (sc_dst == INF || sc_src+c < sc_dst))
	score[dst_ptr] = sc_src + c;
    }

    if (pos[num_seq-1] < row) {
      for (int k = 0; k < num_iconf; k++)
	score[(k+ptr) % ml] = INF;
    }

    int i;

    for (i = 0; i < num_seq; i++) {
      pos[i]++;
      if (pos[i] == seqs[i].getlength()+1) {
	pos[i] = 0;
	if (i == 1)
	  cerr << ".";
      }
      else
	break;
    }

    if (pos[num_seq-1] == row+1 || i == num_seq)
      break;

    //    if (i == num_seq)
    //      break;

    for (int j = 0; j <= i; j++) {
      if (pos[j] < seqs[j].getlength())
	res_next[j] = seqs[j].getres(pos[j]);
      else
	res_next[j] = -1;
    }

    ptr += num_iconf;
 }

  cout << endl;
  for (int k = 0; k < num_iconf; k++)
    cout << " " << score[(k+ptr) % ml];
  cout << endl;

  cout << "ptr " << ptr << endl;


  //------------------------------------------------------------

  vector<cost_int> score_b(ml);

  for (int i = 0; i < ml; i++)
    score_b[i] = INF;

  ptr = 1;
  for (int i = 0; i < num_seq; i++) {
    ptr *= (seqs[i].getlength()+1);
  }
  ptr--;
  ptr *= num_iconf;  // ptr now points to last position
  
  for (int i = 0; i < num_iconf; i++) {
    score_b[(ptr+i) % ml] = 0;
  }

  for (int i = 0; i < num_seq; i++)
    pos[i] = seqs[i].getlength();

  for (int i = 0; i < num_seq; i++)
    res_next[i] = seqs[i].getres(pos[i]-1);

  for (;;) {
    for (int k = 0; k < numjump; k++) {
      cost_int c = jlist[k].get_gap_cost();
      bool no_good = false;
      for (int j = 0; j < num_seq; j++) {
	int rc_j = jumplist.get_res_conf(jlist[k].get_res_conf(), j);
	if (rc_j == 0)
	  res[j] = -1;
	else {
	  if (pos[j] > 0 &&
	      (j < num_seq-1 || pos[j] > row))
	    res[j] = res_next[j];
	  else
	    no_good = true;
	}
      }
      if (no_good)
	continue;
      c += jumplist.get_match_cost(res);
      cost_int sc_src = score_b[(ptr+jlist[k].get_end_indel_conf()) % ml];
      int dst_ptr = (ptr+jlist[k].get_start_indel_conf()
		     -jlist[k].get_length()) % ml;
      cost_int sc_dst = score_b[dst_ptr];
      if (sc_src != INF && (sc_dst == INF || sc_src+c < sc_dst))
	score_b[dst_ptr] = sc_src + c;
    }

    if (pos[num_seq-1] > row)
      for (int k = 0; k < num_iconf; k++)
	score_b[(k+ptr) % ml] = INF;

    int i;

    for (i = 0; i < num_seq; i++) {
      pos[i]--;
      if (pos[i] == -1) {
	pos[i] = seqs[i].getlength();
	if (i == 1)
	  cerr << ".";
      }
      else
	break;
    }

    if (pos[num_seq-1] == row-1 || i == num_seq)
      break;

    for (int j = 0; j <= i; j++)
      if (pos[j] > 0)
	res_next[j] = seqs[j].getres(pos[j]-1);
      else
	res_next[j] = -1;

    ptr -= num_iconf;
 }
  
  cout << "ptr " << ptr << endl;

  for (int k = 0; k < num_iconf; k++)
    cout << " " << score_b[(k+ptr) % ml];
  cout << endl;

  cout << "row_size " << row_size << endl;

  cout << "++++++++++" << endl;

  for (int i = 0; i < num_seq-1; i++)
    pos[i] = 0;

  pos[num_seq-1] = row;

  int ptr0 = ptr; // ptr is start of row after last recursion

  ptr = 0;

  // go through row
  for (;;) {
    for (int k = 0; k < num_iconf; k++) {
      cout << k << "  ";
      for (int j = 0; j < num_seq; j++)
	cout << pos[j] << " ";
      cout << score[(k+ptr+ptr0) % ml] + score_b[(k+ptr+ptr0) % ml] << endl;
    }

    int i;

    for (i = 0; i < num_seq-1; i++) {
      pos[i]++;
      if (pos[i] == seqs[i].getlength()+1)
	pos[i] = 0;
      else
	break;
    }

    if (i == num_seq-1)
      break;

    ptr += num_iconf;
  }
  
  cout << "ptr " << ptr << endl;
}


void align(Tree const &tree, Jumplist &jumplist, vector< Seq > const &seqs)
{
  int ml = jumplist.totlength(seqs);

  int num_seq = seqs.size();
  int num_node = tree.getnumnode();

  jumplist.setlength(seqs);

  vector< Jump > jlist = jumplist.getlist();
  int numjump = jlist.size();
  int num_iconf = jumplist.get_num_indel_conf();

  vector<cost_int> score(ml);

  for (int i = 0; i < ml; i++)
    score[i] = INF;

  int n = 1;
  for (int i = 0; i < num_node-2; i++) {
    n *= 3;
    n++;
  }

  score[jumplist.indelmap(n)] = 0;

  vector< int > pos(num_seq);
  vector< int > res_next(num_seq);
  vector< int > res(num_seq);

  for (int i = 0; i < num_seq; i++)
    pos[i] = 0;

  for (int i = 0; i < num_seq; i++)
    res_next[i] = seqs[i].getres(pos[0]);

  int ptr = 0;

  for (;;) {
    for (int k = 0; k < numjump; k++) {
      cost_int c = jlist[k].get_gap_cost();
      bool no_good = false;
      for (int j = 0; j < num_seq; j++) {
	int rc_j = jumplist.get_res_conf(jlist[k].get_res_conf(), j);
	if (rc_j == 0)
	  res[j] = -1;
	else {
	  if (pos[j] < seqs[j].getlength())
	    res[j] = res_next[j];
	  else
	    no_good = true;
	}
      }
      if (no_good)
	continue;
      c += jumplist.get_match_cost(res);
      cost_int sc_src = score[ptr+jlist[k].get_start_indel_conf()];
      int dst_ptr = ptr+jlist[k].get_end_indel_conf()+jlist[k].get_length();
      cost_int sc_dst = score[dst_ptr];
      if (sc_src != INF && (sc_dst == INF || sc_src+c < sc_dst))
	score[dst_ptr] = sc_src + c;
    }

    int i;

    for (i = 0; i < num_seq; i++) {
      pos[i]++;
      if (pos[i] == seqs[i].getlength()+1) {
	pos[i] = 0;
	//	if (i == 1)
	//	  cerr << ".";
      }
      else
	break;
    }

    if (i == num_seq)
      break;

    for (int j = 0; j <= i; j++) {
      if (pos[j] < seqs[j].getlength())
	res_next[j] = seqs[j].getres(pos[j]);
      else
	res_next[j] = -1;
    }

    ptr += num_iconf;
  }

  int sc_min = score[ptr];

  for (int k = 0; k < num_iconf; k++)
    if (sc_min > score[k+ptr])
      sc_min = score[k+ptr];

  cout << "Score: " << sc_min << endl;

  //  cerr << endl;

  //------------------------------------------------------------

  vector<string> al(num_seq);

  int min = INF, ic = -1;
  for (int k = 0; k < num_iconf; k++) 
    if (score[k+ptr] < min || min == INF) {
      min = score[k+ptr];
      ic = k;
    }

  if (ic == -1) {
    cerr << "Problems..." << endl;
    exit(1);
  }

  ptr = ml - num_iconf;  // ptr now points to last position
  
  for (int i = 0; i < num_seq; i++)
    pos[i] = seqs[i].getlength();

  for (;;) {
    for (int i = 0; i < num_seq; i++)
      res_next[i] = seqs[i].getres(pos[i]-1);

    int k;

    for (k = 0; k < numjump; k++) {
      if (jlist[k].get_end_indel_conf() != ic)
	continue;
      cost_int c = jlist[k].get_gap_cost();
      bool no_good = false;
      for (int j = 0; j < num_seq; j++) {
	int rc_j = jumplist.get_res_conf(jlist[k].get_res_conf(), j);
	if (rc_j == 0)
	  res[j] = -1;
	else {
	  if (pos[j] > 0)
	    res[j] = res_next[j];
	  else
	    no_good = true;
	}
      }
      if (no_good)
	continue;
      c += jumplist.get_match_cost(res);
      cost_int sc_dst = score[ptr+ic];
      cost_int sc_src = score[ptr+jlist[k].get_start_indel_conf()
			     -jlist[k].get_length()];
      if (sc_src != INF && sc_dst != INF && sc_src+c == sc_dst)
	break;
    }

    if (k == numjump) {
      cerr << "Problems..." << endl;
      exit(1);
    }

    bool done = true;

    ic = jlist[k].get_start_indel_conf();

    for (int i = 0; i < num_seq; i++) {
      pos[i] -= jumplist.get_res_conf(jlist[k].get_res_conf(), i);
      if (pos[i] > 0)
	done = false;
    }

    for (int i = 0; i < num_seq; i++) {
      if (jumplist.get_res_conf(jlist[k].get_res_conf(), i) == 1)
	al[i] = seqs[i].getsym(pos[i]) + al[i];
      else
	al[i] = "-" + al[i];
    }

    ptr -= jlist[k].get_length();

    if (done)
      break;
  }

  cout << "Alignment:" << endl;

  for (int i = 0; i < num_seq; i++)
    cout << al[i] << endl;
  
  /*  cout << "ptr " << ptr << endl;

  for (int k = 0; k < num_iconf; k++)
    cout << " " << score[k+ptr];
  cout << endl;
  */
}


// ------------------------------------------------------------

// time affalign "(1,2,3);" SKGVITITDAEFESEVLKAEQPVLVYFWASWCGPCQLMSP MFKVYGYDSNIHKCVYCDNAKRLLTVKKQPFEFINIMPEK MVKQIESKTAFQEALDAAGDKLVVVDFSATWCGPCKMIKP < bl62_dist.cost
// 22.960u

// res_next 23.060u
// edge 22.840u



// DNA 63.430u -> 20.030u
// protein 134.510u -> 49.560u
 
// ACT
// A T
// A 




/*
time affalign "(1,2,3);" ACT AT A < dna.cost | tail -1
time affalign "(1,2,3);" ACT A AT < dna.cost | tail -1
time affalign "(1,2,3);" AT ACT A < dna.cost | tail -1
time affalign "(1,2,3);" AT A ACT < dna.cost | tail -1
time affalign "(1,2,3);" A ACT AT < dna.cost | tail -1
time affalign "(1,2,3);" A AT ACT < dna.cost | tail -1
*/
